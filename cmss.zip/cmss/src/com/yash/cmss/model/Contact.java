package com.yash.cmss.model;
/**
 * this  model to set and get the various variable(attribute)
 *  gonna use throughout the application
 * @author mayank
 *
 */
public class Contact extends Person{
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	private Integer userId;
	
	
}
