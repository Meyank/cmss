package com.yash.cmss.model;

public class Contact extends Person{
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	private String userId;
	
	
}
