package com.yash.cmss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmss.service.ContactService;
import com.yash.cmss.serviceimpl.ContactServiceimpl;

/**
 * Servlet implementation class DeleteMultipleContact
 */
@WebServlet("/DeleteMultipleContact")
public class DeleteMultipleContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ContactService contactService = null;

	public DeleteMultipleContact() {
		contactService = new ContactServiceimpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String[] id = request.getParameterValues("multipleContacts");
		if(id!=null){
		contactService.deleteMultipleContactByID(id);
		response.sendRedirect("./ListContacts?msg=contacts deleted successfully......");
		}
		else{
			response.sendRedirect("./ListContacts?msg=at least one contact needs to be selected......");
		}
		}

}
