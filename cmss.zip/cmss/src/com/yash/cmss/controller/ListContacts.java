package com.yash.cmss.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmss.model.Contact;
import com.yash.cmss.service.ContactService;
import com.yash.cmss.serviceimpl.ContactServiceimpl;

@WebServlet("/ListContacts")
public class ListContacts extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ContactService contactService = null;

	public ListContacts() {

		contactService = new ContactServiceimpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Contact> contactsList = contactService
				.getAllContactsByUserID((Integer) request.getSession().getAttribute("userid"));
		request.setAttribute("contactsList", contactsList);
		String msg = request.getParameter("msg");
		getServletContext().getRequestDispatcher("/list_contacts.jsp?"+msg).forward(request,
				response);

	}

}
