package com.yash.cmss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmss.model.Contact;
import com.yash.cmss.service.ContactService;
import com.yash.cmss.serviceimpl.ContactServiceimpl;

@WebServlet("/AddContactController")
public class AddContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Contact contact = null;
	ContactService contactService = null;

	public AddContactController() {

		contactService = new ContactServiceimpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		contact = new Contact();

//		Integer id = Integer.parseInt(request.getParameter("id"));
//		System.out.println(id);
		String act = request.getParameter("act");
		if (act.equalsIgnoreCase("update")) {
			contact.setId(Integer.parseInt(request.getParameter("id")));
			contact.setAddress(request.getParameter("address"));
			contact.setEmail(request.getParameter("email"));
			contact.setContact(request.getParameter("contact"));
			contact.setName(request.getParameter("name"));
			contactService.updateContact(contact);
			response.sendRedirect("./ListContacts?msg=Contact updated successfully........");
		} 
		else {
			contact.setUserId((Integer) request.getSession().getAttribute("userid"));
			contact.setAddress(request.getParameter("address"));
			contact.setEmail(request.getParameter("email"));
			contact.setContact(request.getParameter("contact"));
			contact.setName(request.getParameter("name"));
			contactService.addContact(contact);
			response.sendRedirect("./ListContacts?msg=Contact added successfully........");
		}
	}
}
