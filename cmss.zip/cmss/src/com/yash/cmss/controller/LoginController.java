package com.yash.cmss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cmss.model.User;
import com.yash.cmss.serviceimpl.UserServiceimpl;

/**
 * this controller will send the logged in user to his dashboard
 * 
 * @author mayank
 *
 */

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserServiceimpl userServiceImpl = null;
	
	public LoginController() {
		userServiceImpl =new UserServiceimpl();
	}

	/**
	 * this will redirect the user to his dashboard after filtering the details
	 * enterd by user
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user =userServiceImpl.authenticateUser(request.getParameter("username"),request.getParameter("password"));
		if(user!=null){
		System.out.println(user.getId());
		HttpSession session = request.getSession(true);
		session.setAttribute("user", user);
		session.setAttribute("userid", user.getId());
		session.setAttribute("username", user.getUsername());
		response.sendRedirect("./homeafterlogin.jsp");
		}
		else{
			response.sendRedirect("./home.jsp?msg=Login failed");
		

	}}

}
