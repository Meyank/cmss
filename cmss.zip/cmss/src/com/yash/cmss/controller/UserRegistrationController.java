package com.yash.cmss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yash.cmss.model.User;
import com.yash.cmss.service.UserService;
import com.yash.cmss.serviceimpl.UserServiceimpl;


public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private UserService userService= null;
  
    public UserRegistrationController() {
        super();
     userService = new UserServiceimpl(); 
    }

	



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		user.setContact(request.getParameter("contact"));
		user.setPassword(request.getParameter("password"));
		user.setUsername(request.getParameter("username"));
		userService.registerUser(user);
		response.sendRedirect("home.jsp?msg=you are registered user can login here!!");
	}

}
