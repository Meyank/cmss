package com.yash.cmss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmss.model.Contact;
import com.yash.cmss.service.ContactService;
import com.yash.cmss.serviceimpl.ContactServiceimpl;

/**
 * Servlet implementation class EditContactController
 */
@WebServlet("/EditContactController")
public class EditContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ContactService contactService = null;

	public EditContactController() {
		contactService = new ContactServiceimpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Contact contact = contactService.retrieveData(id);
		System.out.println(contact.getName());

		request.setAttribute("contact", contact);
		request.getRequestDispatcher("/contact_add.jsp?act=update").forward(request, response);
		
	}

}
