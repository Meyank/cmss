package com.yash.cmss.service;

import java.util.List;

import com.yash.cmss.model.Contact;

public interface ContactService {
	
	void addContact(Contact contact);

	List<Contact> getAllContactsByUserID(Integer userId);

	void deleteContactByID(int id);

	void deleteMultipleContactByID(String[] id);

	Contact retrieveData(int id);

	void updateContact(Contact contact);

	
	

}
