package com.yash.cmss.service;

import com.yash.cmss.model.User;
/**
 * this will declare all the  related operation for user 
 * @author mayank
 *
 */
public interface  UserService {
 public void  registerUser(User user);

public User authenticateUser(String username, String password);
}
