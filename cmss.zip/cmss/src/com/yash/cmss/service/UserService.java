package com.yash.cmss.service;

import com.yash.cmss.model.User;

public interface  UserService {
 public void  registerUser(User user);

public String authenticateUser(String username, String password);
}
