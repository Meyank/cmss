package com.yash.cmss.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.cmss.dao.UserDAO;
import com.yash.cmss.model.User;
import com.yash.cmss.util.DbUtil;
/**
 * here all the methods declared in DAO will be implemented 
 * @author mayank
 *
 */
public class UserDAOImpl implements UserDAO {
/**
 * this mthod will enter a new user in db
 */
	@Override
	public void insert(User user) {
		String sql = "Insert into users(username,password,contact) values (?,?,?)";
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getContact());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
