package com.yash.cmss.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.cmss.dao.UserDAO;
import com.yash.cmss.model.User;
import com.yash.cmss.util.DbUtil;

public class UserDAOImpl implements UserDAO {

	@Override
	public void insert(User user) {
		String sql = "Insert into users(username,password,contact) values (?,?,?)";
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getContact());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
