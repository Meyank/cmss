package com.yash.cmss.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.cmss.dao.ContactDAO;
import com.yash.cmss.model.Contact;
import com.yash.cmss.util.DbUtil;

public class ContactDAOimpl implements ContactDAO {
	@Override
	public void insert(Contact contact) {

		String sql = "INSERT INTO contacts (name,userId,contact,email,address) VALUES(?,?,?,?,?)";
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {

			pstmt.setString(1, contact.getName());
			pstmt.setInt(2, contact.getUserId());
			pstmt.setString(3, contact.getContact());
			pstmt.setString(4, contact.getEmail());
			pstmt.setString(5, contact.getAddress());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Contact> getAllContactsByUserID(Integer userId) {
		List<Contact> contactsList = new ArrayList<Contact>();
		Contact contact;
		String sql = "SELECT * FROM contacts WHERE userId=?;";
		try {
			PreparedStatement pstmt = DbUtil.prepareStatement(sql);

			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				contact = new Contact();
				contact.setId(rs.getInt("id"));
				contact.setAddress(rs.getString("address"));
				contact.setUserId(rs.getInt("userId"));
				contact.setEmail(rs.getString("email"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contactsList.add(contact);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return contactsList;
	}

	@Override
	public void delete(int id) {
		String sql = "Delete from contacts  where id=?";
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setInt(1, id);
			pstmt.execute();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	@Override
	public Contact retrieveContact(int id) {
		System.out.println(id);
		Contact contact;
		String sql = "SELECT * FROM contacts WHERE id=?";
		try {
			PreparedStatement pstmt = DbUtil.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				contact = new Contact();
				contact.setId(rs.getInt("id"));
				contact.setAddress(rs.getString("address"));
				contact.setUserId(rs.getInt("userId"));
				contact.setEmail(rs.getString("email"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				return contact;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateContact(Contact contact) {

		String sql = "update contacts set name=?,contact=?,email=?,address=? where id=?;";
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setString(1, contact.getName());
			pstmt.setString(2, contact.getContact());
			pstmt.setString(3, contact.getEmail());
			pstmt.setString(4, contact.getAddress());
			pstmt.setInt(5, contact.getId());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}