package com.yash.cmss.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.cmss.dao.UserDAO;
import com.yash.cmss.daoimpl.UserDAOImpl;
import com.yash.cmss.model.User;
import com.yash.cmss.service.UserService;
import com.yash.cmss.util.DbUtil;

public class UserServiceimpl implements UserService {

	UserDAO userDAO = null;

	public UserServiceimpl() {
		userDAO = new UserDAOImpl();
	}

	@Override
	public void registerUser(User user) {
		userDAO.insert(user);

	}

	@Override
	public String authenticateUser(String username, String password) {
		String sql = "select * from users where username=? and password=?";
		String user_name=null;
		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
			user_name=rs.getString("username");
			return user_name;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user_name;

	}

}
