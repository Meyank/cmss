package com.yash.cmss.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.cmss.dao.UserDAO;
import com.yash.cmss.daoimpl.UserDAOImpl;
import com.yash.cmss.model.User;
import com.yash.cmss.service.UserService;
import com.yash.cmss.util.DbUtil;
/**
 * here all the methods declared in serviceimpl will be implemented 
 * @author mayank
 *
 */
public class UserServiceimpl implements UserService {
/**
 * reference to the userDAO interface 
 */
	UserDAO userDAO = null;
/**
 * an object to userdaoimplis paased in userdao refernce here 
 */
	public UserServiceimpl() {
		userDAO = new UserDAOImpl();
	}
/**
 * this is to accept the data from controller and pass it to the userdaoimpl
 */
	@Override
	public void registerUser(User user) {
		userDAO.insert(user);

	}
/**
 * this is to check the credential enterd from user if right then the name of the user is returned 
 * to the filter and thereafter 
 */
	@Override
	public User authenticateUser(String username, String password) {
		User user =null;
		String sql = "select * from users where username=? and password=?";

		PreparedStatement pstmt = DbUtil.prepareStatement(sql);
		try {
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				
				user=new User();
			user.setUsername(rs.getString("username"));
			user.setEmail(rs.getString("email"));
			user.setContact(rs.getString("contact"));
			user.setAddress(rs.getString("address"));
			user.setId(rs.getInt("id"));
			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;

	}

}
