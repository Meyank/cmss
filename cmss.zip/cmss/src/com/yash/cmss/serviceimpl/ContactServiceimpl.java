package com.yash.cmss.serviceimpl;

import java.util.List;

import com.yash.cmss.dao.ContactDAO;
import com.yash.cmss.daoimpl.ContactDAOimpl;
import com.yash.cmss.model.Contact;
import com.yash.cmss.service.ContactService;

public class ContactServiceimpl implements ContactService {
	ContactDAO contactDAO = null;

	public ContactServiceimpl() {
		contactDAO = new ContactDAOimpl();
	}

	@Override
	public void addContact(Contact contact) {
		contactDAO.insert(contact);
	}

	@Override
	public List<Contact> getAllContactsByUserID(Integer userId) {
		List<Contact> contactsList = contactDAO.getAllContactsByUserID(userId);
		return contactsList;
	}

	@Override
	public void deleteContactByID(int id) {
		contactDAO.delete(id);
	}

	@Override
	public void deleteMultipleContactByID(String[] id) {

		int length = id.length;
		Integer parsed_id ;

		for (int i = 0; i < length; i++) {
			parsed_id = Integer.parseInt(id[i]);
			contactDAO.delete(parsed_id);
		}
	}

	@Override
	public Contact retrieveData(int id) {
		return contactDAO.retrieveContact(id);
		
	}

	@Override
	public void updateContact(Contact contact) {
		
		contactDAO.updateContact(contact);
	} 
	
	

}
