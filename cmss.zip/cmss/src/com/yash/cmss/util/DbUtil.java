package com.yash.cmss.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DbUtil {

	private static String driverName = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost/cmss";
	private static String user = "root";
	private static String pass = "root";
	private static Connection con = null;
	private static PreparedStatement pstmt = null;
	static {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
		}

	}

	public static Connection connect() {
		try {
			con = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return con;

	}

	public static PreparedStatement prepareStatement(String sql) {
		connect();
		try {
			pstmt = con.prepareStatement(sql);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return pstmt;
	}

	public static void closeStatement() {
		try {
			pstmt.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
