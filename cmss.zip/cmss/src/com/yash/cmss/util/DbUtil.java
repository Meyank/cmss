package com.yash.cmss.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 * util class to get various utilities to use in application
 * @author mayank
 *
 */
public class DbUtil {
/**
 * driver name 
 */
	private static String driverName = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost/cmss";
	private static String user = "root";
	private static String pass = "root";
	private static Connection con = null;
	private static PreparedStatement pstmt = null;
	static {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
		}

	}
/**
 * this is to return the connection object to the db
 * @return
 */
	public static Connection connect() {
		try {
			con = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return con;

	}
/**
 * this is to return  preparestatment object 
 * @param sql
 * @return
 */
	public static PreparedStatement prepareStatement(String sql) {
		connect();
		try {
			pstmt = con.prepareStatement(sql);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return pstmt;
	}
/**
 * to close the connection to the preparestmnt
 */
	public static void closeStatement() {
		try {
			pstmt.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	/**
	 * to close the connection to the connection
	 */
	public void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
