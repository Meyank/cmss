package com.yash.cmss.dao;

import java.util.List;

import com.yash.cmss.model.Contact;

public interface ContactDAO {
void  insert(Contact contact);

List<Contact> getAllContactsByUserID(Integer userId);

void delete(int id);

Contact retrieveContact(int id);

void updateContact(Contact contact);
}
