package com.yash.cmss.dao;

import com.yash.cmss.model.User;
/**
 * this will declare all the db related operation for user 
 * @author mayank
 *
 */
public interface UserDAO {
	/**
	 * this is to insert a new user in db
	 * @param user
	 */
 public void insert(User user);
	
	
	
	
}
