package com.yash.cmss.dao;

import com.yash.cmss.model.User;

public interface UserDAO {
 public void insert(User user);
	
	
	
	
}
